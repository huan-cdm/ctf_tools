'''
import os
import binascii
import struct

crcbp = open("flag.png", "rb").read()    #打开图片（修改图片路径）
for i in range(2000):
    for j in range(2000):
        data = crcbp[12:16] + \
            struct.pack('>i', i)+struct.pack('>i', j)+crcbp[24:29]
        crc32 = binascii.crc32(data) & 0xffffffff
        #crc32 int型
        print(type(crc32))
        if(crc32 == 0x9BF1293B):    #图片当前CRC（修改CRC）
            print(i, j)
            print('hex:', hex(i), hex(j))
'''
import os
import binascii
import struct

def get_png_crc(filename):
    """获取PNG图片IHDR块的CRC值"""
    with open(filename, "rb") as f:
        data = f.read()
        ihdr_start = data.index(b'IHDR')  # 找到IHDR块
        crc_bytes = data[ihdr_start + 17: ihdr_start + 21]  # CRC是IHDR后17-20字节
        return int.from_bytes(crc_bytes, byteorder='big')

def brute_force_png_dimensions(filename, target_crc=None):
    """暴力破解PNG图片的正确尺寸"""
    crcbp = open(filename, "rb").read()
    
    # 如果没有提供目标CRC，则自动从文件中提取
    if target_crc is None:
        target_crc = get_png_crc(filename)
    
    print(f"目标CRC值: 0x{target_crc:08X}")
    print("开始暴力破解...")
    
    for i in range(2000):
        for j in range(2000):
            # 构造IHDR块数据(不包括长度字段)
            data = crcbp[12:16] + \
                   struct.pack('>i', i) + struct.pack('>i', j) + crcbp[24:29]
            crc32 = binascii.crc32(data) & 0xffffffff
            
            if crc32 == target_crc:
                print(f"找到匹配的尺寸: 宽度={i}, 高度={j}")
                print(f"十六进制: 宽度=0x{i:X}, 高度=0x{j:X}")
                return (i, j)
    
    print("在指定范围内未找到匹配的尺寸")
    return None

# 使用示例
if __name__ == "__main__":
    png_file = "flag.png"
    
    # 自动获取CRC并开始破解
    brute_force_png_dimensions(png_file)