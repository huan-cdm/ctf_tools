from PIL import Image

gif = Image.open('hehe.gif')
for frame in range(0, gif.n_frames):
    gif.seek(frame)
    gif.save(f'frame_{frame}.png')